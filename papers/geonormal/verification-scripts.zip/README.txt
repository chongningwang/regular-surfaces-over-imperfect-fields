Verification scripts for Geometric singularities of K-trivial regular surfaces

This archive accompanies the paper's appendix "Verification scripts".
It contains the exact script files, directory README files and recorded outputs
from the paper's source tree. Preserve the smooth/ and p11/ directories.

Requirements

Use Python 3 with SymPy, NetworkX and NumPy for the Python scripts, and Singular
for the .sing scripts. The characteristic-13 search uses the fork multiprocessing
method. The directory README files record the versions used for the saved checks.

Run commands from the directory containing this file.

    python3 smooth/configs.py
    python3 smooth/crosscheck.py
    python3 smooth/p13.py
    python3 smooth/p17.py
    python3 p11/p11_checks.py
    Singular -q p11/ekedahl.sing
    python3 smooth/small_primes_checks.py
    Singular -q smooth/small_primes_local.sing
    python3 smooth/small_primes_lift_checks.py
    python3 smooth/nonrational_checks.py
    Singular -q smooth/p17_local.sing

The first four commands perform the configuration enumerations and take longer
than the identity checks. See smooth/README.md and p11/README.md for their roles.

Expected enumeration results

For d = 1, 2, 3, 4 and r = 8+d, the prime determinant values in configs.py are
respectively: none; 5 and 17; 5; and 13, 53 and 113.
The complete determinant sets are recorded in smooth/configs.out.
The simple-tree determinant sets agree with smooth/crosscheck.out. The general
search also allows tangencies and triple points.
For det A in {p,p^3} and 1 <= d <= 3, p13.py gives no configuration, and p17.py
gives one configuration up to isomorphism, with d = 2 and r = 10.
The local check p17_local.sing concerns one representative. The paper's argument
excludes all analytic types with the surviving graph.

The configuration classification in the paper retains these computer-assisted
steps. The explicit identity and chart scripts supplement the proofs in the paper.
The mixed-characteristic lift check concerns only the characteristic-19 model
and its single blowup in Proposition prop:small-primes-lift.

Integrity

SHA256SUMS records the SHA-256 digest of every other member of this archive.
Where sha256sum is available, verify the extracted files with

    sha256sum -c SHA256SUMS

License

The scripts, recorded outputs and documentation in this archive are licensed
under the Apache License 2.0; see LICENSE. The accompanying manuscript is
licensed separately under CC BY 4.0.
